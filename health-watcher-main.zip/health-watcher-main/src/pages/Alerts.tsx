import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, X, Bell, CheckCircle } from "lucide-react";

const Alerts = () => {
  const { alerts, dismissAlert } = useHealthData();

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-heading text-3xl font-bold">Alert Center</h1>
        <p className="text-muted-foreground mt-1">Active health risk notifications</p>
      </motion.div>

      {alerts.length === 0 ? (
        <GlassCard className="text-center py-12">
          <CheckCircle className="w-16 h-16 text-success mx-auto mb-4" />
          <h2 className="font-heading text-xl font-bold">All Clear!</h2>
          <p className="text-muted-foreground mt-2">No active alerts at this time.</p>
        </GlassCard>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {alerts.map((alert, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20, height: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="glass-card p-4 border-l-4 border-destructive flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center flex-shrink-0">
                    <AlertTriangle className="w-5 h-5 text-destructive" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{alert}</p>
                    <p className="text-xs text-muted-foreground mt-1">Immediate action recommended</p>
                  </div>
                  <button onClick={() => dismissAlert(i)}
                    className="p-1.5 rounded-lg hover:bg-muted/50 text-muted-foreground transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <GlassCard delay={0.3} className="mt-8">
        <h2 className="font-heading font-semibold mb-3 flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary" /> Alert Protocol
        </h2>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>• <strong>High Risk:</strong> Fever &gt; 50 + High Rainfall + Poor Water → Dengue alert</p>
          <p>• <strong>Medium Risk:</strong> Fever 20–50 OR High Population Density → Viral fever watch</p>
          <p>• <strong>Low Risk:</strong> Normal conditions → Routine monitoring</p>
        </div>
      </GlassCard>
    </div>
  );
};

export default Alerts;
