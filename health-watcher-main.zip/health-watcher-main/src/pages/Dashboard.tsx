import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import StatCard from "@/components/StatCard";
import FloatingOrbs from "@/components/FloatingOrbs";
import { motion } from "framer-motion";
import { Activity, AlertTriangle, Bell, MapPin, TrendingUp, Shield, ArrowUpRight, Zap } from "lucide-react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const { records, alerts } = useHealthData();

  const totalCases = records.reduce((sum, r) => sum + r.feverCases, 0);
  const highRiskAreas = records.filter((r) => r.riskLevel === "High").length;
  const alertCount = alerts.length;

  const stats = [
    { label: "Total Fever Cases", value: totalCases, icon: Activity, trend: "+12%", color: "risk-medium", gradient: "gradient-primary" },
    { label: "High Risk Zones", value: highRiskAreas, icon: AlertTriangle, trend: "Critical", color: "risk-high", gradient: "bg-destructive" },
    { label: "Active Alerts", value: alertCount, icon: Bell, trend: "Live", color: "risk-medium", gradient: "bg-amber-500" },
    { label: "Locations Tracked", value: records.length, icon: MapPin, trend: "Active", color: "risk-low", gradient: "bg-secondary" },
  ];

  const quickActions = [
    { label: "Input Data", to: "/data-input", icon: Zap, desc: "Add new surveillance data" },
    { label: "View Results", to: "/results", icon: TrendingUp, desc: "Risk analysis results" },
    { label: "Analytics", to: "/analytics", icon: Activity, desc: "Charts & insights" },
    { label: "Risk Map", to: "/map", icon: MapPin, desc: "Geographic overview" },
  ];

  return (
    <div className="relative min-h-screen">
      <FloatingOrbs />
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Live Monitoring</span>
          </div>
          <h1 className="font-heading text-4xl lg:text-5xl font-extrabold tracking-tight">
            Health <span className="gradient-text">Command Center</span>
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">Real-time disease surveillance & outbreak detection</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {stats.map((stat, i) => (
            <StatCard key={stat.label} {...stat} delay={i * 0.1} />
          ))}
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8">
          {/* Recent Activity - spans 2 cols */}
          <GlassCard delay={0.4} className="lg:col-span-2">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-heading text-lg font-bold flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" /> Recent Activity
              </h2>
              <Link to="/results" className="text-xs font-semibold text-primary flex items-center gap-1 hover:underline">
                View all <ArrowUpRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="space-y-2.5">
              {records.slice(-5).reverse().map((r, i) => (
                <motion.div
                  key={r.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.08 }}
                  className="flex items-center justify-between p-3.5 rounded-xl bg-muted/40 hover:bg-muted/70 transition-all duration-300 group cursor-default"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2.5 h-2.5 rounded-full ${
                      r.riskLevel === "High" ? "bg-destructive animate-pulse" : r.riskLevel === "Medium" ? "bg-amber-500" : "bg-success"
                    }`} />
                    <div>
                      <p className="font-medium text-sm">{r.location}</p>
                      <p className="text-xs text-muted-foreground mono">{r.feverCases} cases · {r.timestamp}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-muted text-muted-foreground">{r.disease}</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      r.riskLevel === "High" ? "risk-high" : r.riskLevel === "Medium" ? "risk-medium" : "risk-low"
                    }`}>
                      {r.riskLevel}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Risk Breakdown */}
          <GlassCard delay={0.5}>
            <h2 className="font-heading text-lg font-bold flex items-center gap-2 mb-5">
              <Shield className="w-5 h-5 text-secondary" /> Risk Breakdown
            </h2>
            <div className="space-y-5">
              {(["High", "Medium", "Low"] as const).map((level) => {
                const count = records.filter((r) => r.riskLevel === level).length;
                const pct = records.length ? Math.round((count / records.length) * 100) : 0;
                const colors = {
                  High: { bar: "bg-destructive", text: "text-destructive", bg: "bg-destructive/10" },
                  Medium: { bar: "bg-amber-500", text: "text-amber-500", bg: "bg-amber-500/10" },
                  Low: { bar: "bg-success", text: "text-success", bg: "bg-success/10" },
                };
                const c = colors[level];
                return (
                  <div key={level}>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${c.bar}`} />
                        <span className="font-medium">{level} Risk</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`mono font-bold ${c.text}`}>{count}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-md font-semibold ${c.bg} ${c.text}`}>{pct}%</span>
                      </div>
                    </div>
                    <div className="h-2 rounded-full bg-muted/60 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 1.2, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
                        className={`h-full rounded-full ${c.bar}`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Mini donut visualization */}
            <div className="mt-6 pt-5 border-t border-border/50">
              <div className="flex items-center justify-center">
                <svg width="100" height="100" viewBox="0 0 100 100" className="drop-shadow-lg">
                  {(["Low", "Medium", "High"] as const).map((level, i) => {
                    const count = records.filter((r) => r.riskLevel === level).length;
                    const pct = records.length ? (count / records.length) * 100 : 0;
                    const cumulative = (["Low", "Medium", "High"] as const).slice(0, i).reduce((acc, l) => {
                      const c = records.filter((r) => r.riskLevel === l).length;
                      return acc + (records.length ? (c / records.length) * 100 : 0);
                    }, 0);
                    const r = 40;
                    const circumference = 2 * Math.PI * r;
                    const strokeDasharray = `${(pct / 100) * circumference} ${circumference}`;
                    const strokeDashoffset = -(cumulative / 100) * circumference;
                    const color = level === "High" ? "hsl(0, 84%, 60%)" : level === "Medium" ? "hsl(38, 92%, 50%)" : "hsl(158, 64%, 52%)";
                    return (
                      <motion.circle
                        key={level}
                        cx="50" cy="50" r={r}
                        fill="none" stroke={color} strokeWidth="10"
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 1.5, delay: 0.8 + i * 0.2 }}
                        transform="rotate(-90 50 50)"
                      />
                    );
                  })}
                  <text x="50" y="48" textAnchor="middle" className="fill-foreground font-bold text-lg" style={{ fontSize: 18 }}>
                    {records.length}
                  </text>
                  <text x="50" y="62" textAnchor="middle" className="fill-muted-foreground" style={{ fontSize: 9 }}>
                    ZONES
                  </text>
                </svg>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h2 className="font-heading text-lg font-bold mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-warning" /> Quick Actions
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, i) => (
              <Link key={action.to} to={action.to}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + i * 0.08 }}
                  whileHover={{ y: -4, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="glass-card p-5 cursor-pointer group hover:border-primary/30 transition-all duration-300"
                >
                  <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <action.icon className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <p className="font-semibold text-sm">{action.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{action.desc}</p>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
