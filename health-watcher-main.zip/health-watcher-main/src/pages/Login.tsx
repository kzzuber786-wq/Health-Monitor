import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import { Activity, LogIn, Eye, EyeOff, ArrowRight } from "lucide-react";
import FloatingOrbs from "@/components/FloatingOrbs";

const Login = () => {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !password) {
      setMessage({ type: "error", text: "All fields are required" });
      return;
    }
    const result = login(userId, password);
    setMessage({ type: result.success ? "success" : "error", text: result.message });
    if (result.success) setTimeout(() => navigate("/dashboard"), 500);
  };

  const inputClass = "w-full px-4 py-3.5 rounded-xl bg-white/5 border border-white/10 text-primary-foreground placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition-all duration-300 text-sm";

  return (
    <div className="min-h-screen flex items-center justify-center gradient-hero p-4 relative overflow-hidden">
      <FloatingOrbs />
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl p-8 sm:p-10 w-full max-w-md"
        style={{ boxShadow: '0 25px 60px rgba(0,0,0,0.3)' }}
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-5"
            style={{ boxShadow: '0 0 40px hsl(199, 89%, 48%, 0.3)' }}
          >
            <Activity className="w-8 h-8 text-primary-foreground" />
          </motion.div>
          <h1 className="font-heading text-2xl font-extrabold text-primary-foreground tracking-tight">Welcome Back</h1>
          <p className="text-white/40 mt-1 text-sm">Sign in to Smart Health Alert System</p>
        </div>

        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            className={`p-3.5 rounded-xl mb-5 text-sm font-medium border ${
              message.type === "error"
                ? "bg-destructive/15 text-red-300 border-red-500/20"
                : "bg-success/15 text-green-300 border-green-500/20"
            }`}
          >
            {message.text}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-white/50 mb-2 uppercase tracking-wider">User ID</label>
            <input type="text" value={userId} onChange={(e) => setUserId(e.target.value)} className={inputClass} placeholder="Enter your User ID" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-white/50 mb-2 uppercase tracking-wider">Password</label>
            <div className="relative">
              <input type={showPw ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} className={inputClass} placeholder="Enter your password" />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3.5 top-3.5 text-white/30 hover:text-white/60 transition-colors">
                {showPw ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
              </button>
            </div>
          </div>
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full btn-primary py-3.5 text-sm flex items-center justify-center gap-2 mt-6"
          >
            Sign In <ArrowRight className="w-4 h-4" />
          </motion.button>
        </form>

        <p className="text-center mt-7 text-white/40 text-sm">
          Don't have an account?{" "}
          <Link to="/signup" className="text-secondary font-semibold hover:text-secondary/80 transition-colors">Create one</Link>
        </p>
      </motion.div>
    </div>
  );
};

export default Login;
