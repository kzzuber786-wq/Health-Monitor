import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import FloatingOrbs from "@/components/FloatingOrbs";
import { motion } from "framer-motion";
import { Line, Bar, Pie, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Title, Tooltip, Legend, Filler
} from "chart.js";
import { BarChart3, TrendingUp, PieChart, Activity } from "lucide-react";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend, Filler);

const Analytics = () => {
  const { records } = useHealthData();

  const baseOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: "bottom" as const, labels: { padding: 16, usePointStyle: true, pointStyleWidth: 8 } },
      tooltip: { backgroundColor: "rgba(0,0,0,0.8)", padding: 12, cornerRadius: 12, titleFont: { size: 13 }, bodyFont: { size: 12 } },
    },
    scales: {
      x: { grid: { display: false }, ticks: { font: { size: 11 } } },
      y: { grid: { color: "rgba(0,0,0,0.04)" }, ticks: { font: { size: 11 } } },
    },
  };

  const lineData = {
    labels: records.map(r => r.location),
    datasets: [{
      label: "Fever Cases",
      data: records.map(r => r.feverCases),
      borderColor: "hsl(199, 89%, 48%)",
      backgroundColor: "hsla(199, 89%, 48%, 0.08)",
      fill: true, tension: 0.4, pointRadius: 5, pointHoverRadius: 8,
      pointBackgroundColor: "hsl(199, 89%, 48%)",
      pointBorderColor: "white", pointBorderWidth: 2,
    }],
  };

  const barData = {
    labels: records.map(r => r.location),
    datasets: [{
      label: "Risk Score",
      data: records.map(r => r.riskLevel === "High" ? 3 : r.riskLevel === "Medium" ? 2 : 1),
      backgroundColor: records.map(r =>
        r.riskLevel === "High" ? "hsl(0, 84%, 60%)" : r.riskLevel === "Medium" ? "hsl(38, 92%, 50%)" : "hsl(158, 64%, 52%)"
      ),
      borderRadius: 12, borderSkipped: false,
    }],
  };

  const riskCounts = { High: 0, Medium: 0, Low: 0 };
  records.forEach(r => riskCounts[r.riskLevel]++);

  const doughnutData = {
    labels: ["High Risk", "Medium Risk", "Low Risk"],
    datasets: [{
      data: [riskCounts.High, riskCounts.Medium, riskCounts.Low],
      backgroundColor: ["hsl(0, 84%, 60%)", "hsl(38, 92%, 50%)", "hsl(158, 64%, 52%)"],
      borderWidth: 0, spacing: 4, borderRadius: 6,
    }],
  };

  const charts = [
    { title: "Cases Trend", icon: TrendingUp, chart: <Line data={lineData} options={baseOpts} />, span: "lg:col-span-2" },
    { title: "Risk Per Area", icon: BarChart3, chart: <Bar data={barData} options={{ ...baseOpts }} /> },
    { title: "Risk Distribution", icon: PieChart, chart: <Doughnut data={doughnutData} options={{ ...baseOpts, scales: undefined, cutout: "65%" }} /> },
  ];

  return (
    <div className="relative min-h-screen">
      <FloatingOrbs />
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Intelligence</span>
          </div>
          <h1 className="font-heading text-3xl lg:text-4xl font-extrabold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground mt-2">Visual insights from health surveillance data</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {charts.map((c, i) => (
            <GlassCard key={c.title} delay={i * 0.15} className={c.span || ""}>
              <h2 className="font-heading font-bold mb-4 flex items-center gap-2 text-sm">
                <c.icon className="w-4 h-4 text-primary" /> {c.title}
              </h2>
              <div className="h-72">{c.chart}</div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Analytics;
