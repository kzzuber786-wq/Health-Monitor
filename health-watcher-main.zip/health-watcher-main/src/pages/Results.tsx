import { useHealthData, HealthRecord } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle, Info, Shield, Stethoscope, Lightbulb } from "lucide-react";

const recommendations: Record<string, string[]> = {
  High: [
    "Immediately deploy fumigation teams in the area",
    "Set up emergency medical camps",
    "Issue public health advisory",
    "Distribute mosquito nets and repellents",
    "Ensure clean water supply to affected areas",
  ],
  Medium: [
    "Increase health surveillance in the area",
    "Conduct awareness campaigns",
    "Monitor water quality regularly",
    "Prepare medical resources for potential escalation",
  ],
  Low: [
    "Continue regular health monitoring",
    "Maintain clean water supply",
    "Encourage personal hygiene practices",
  ],
};

const RiskBadge = ({ level }: { level: string }) => {
  const config = {
    High: { icon: AlertTriangle, class: "risk-high", bg: "bg-destructive" },
    Medium: { icon: Info, class: "risk-medium", bg: "bg-warning" },
    Low: { icon: CheckCircle, class: "risk-low", bg: "bg-success" },
  }[level] || { icon: CheckCircle, class: "risk-low", bg: "bg-success" };

  return (
    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.3 }}
      className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full border text-lg font-bold ${config.class}`}>
      <config.icon className="w-5 h-5" /> {level} Risk
    </motion.div>
  );
};

const ResultCard = ({ record, index }: { record: HealthRecord; index: number }) => (
  <GlassCard delay={index * 0.1} className="space-y-4">
    <div className="flex items-start justify-between flex-wrap gap-3">
      <div>
        <h3 className="font-heading text-xl font-bold">{record.location}</h3>
        <p className="text-sm text-muted-foreground">{record.timestamp}</p>
      </div>
      <RiskBadge level={record.riskLevel} />
    </div>

    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {[
        { label: "Fever Cases", value: record.feverCases },
        { label: "Rainfall", value: record.rainfall },
        { label: "Water Quality", value: record.waterQuality },
        { label: "Density", value: record.populationDensity },
      ].map((item) => (
        <div key={item.label} className="p-3 rounded-lg bg-muted/50 text-center">
          <p className="text-xs text-muted-foreground">{item.label}</p>
          <p className="font-semibold mt-0.5">{item.value}</p>
        </div>
      ))}
    </div>

    <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5">
      <Stethoscope className="w-5 h-5 text-primary flex-shrink-0" />
      <div>
        <span className="text-sm text-muted-foreground">Prediction: </span>
        <span className="font-semibold">{record.disease}</span>
      </div>
    </div>

    <div>
      <h4 className="flex items-center gap-1.5 text-sm font-semibold mb-2">
        <Lightbulb className="w-4 h-4 text-warning" /> Recommendations
      </h4>
      <ul className="space-y-1">
        {recommendations[record.riskLevel]?.map((rec, i) => (
          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
            <Shield className="w-3.5 h-3.5 mt-0.5 text-secondary flex-shrink-0" />
            {rec}
          </li>
        ))}
      </ul>
    </div>
  </GlassCard>
);

const Results = () => {
  const { records } = useHealthData();

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-heading text-3xl font-bold">Risk Analysis Results</h1>
        <p className="text-muted-foreground mt-1">Detailed risk assessment for all monitored locations</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {records.slice().reverse().map((record, i) => (
          <ResultCard key={record.id} record={record} index={i} />
        ))}
      </div>
    </div>
  );
};

export default Results;
