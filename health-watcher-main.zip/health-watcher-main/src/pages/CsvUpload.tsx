import { useState, useRef } from "react";
import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import { motion } from "framer-motion";
import { Upload, FileSpreadsheet, CheckCircle } from "lucide-react";
import Papa from "papaparse";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

interface CsvRow {
  location: string;
  feverCases: number;
  rainfall: string;
  waterQuality: string;
  populationDensity: string;
}

const CsvUpload = () => {
  const { addRecord } = useHealthData();
  const [rows, setRows] = useState<CsvRow[]>([]);
  const [imported, setImported] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const parsed = result.data.map((row: any) => ({
          location: row.location || row.Location || "",
          feverCases: parseInt(row.feverCases || row["Fever Cases"] || "0"),
          rainfall: row.rainfall || row.Rainfall || "Low",
          waterQuality: row.waterQuality || row["Water Quality"] || "Good",
          populationDensity: row.populationDensity || row["Population Density"] || "Low",
        }));
        setRows(parsed);
      },
    });
  };

  const handleImport = () => {
    rows.forEach((row) => {
      addRecord({
        location: row.location,
        feverCases: row.feverCases,
        rainfall: row.rainfall as any,
        waterQuality: row.waterQuality as any,
        populationDensity: row.populationDensity as any,
      });
    });
    setImported(true);
  };

  const chartData = rows.length > 0 ? {
    labels: rows.map((r) => r.location),
    datasets: [{
      label: "Fever Cases",
      data: rows.map((r) => r.feverCases),
      backgroundColor: "hsl(199, 89%, 48%)",
      borderRadius: 8,
    }],
  } : null;

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-heading text-3xl font-bold">CSV Upload</h1>
        <p className="text-muted-foreground mt-1">Upload health data in CSV format for bulk analysis</p>
      </motion.div>

      <GlassCard className="mb-6">
        <div
          className="border-2 border-dashed border-border rounded-xl p-12 text-center cursor-pointer hover:border-primary/50 transition-colors"
          onClick={() => fileRef.current?.click()}
        >
          <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="font-medium">Click to upload CSV file</p>
          <p className="text-sm text-muted-foreground mt-1">Headers: location, feverCases, rainfall, waterQuality, populationDensity</p>
          <input ref={fileRef} type="file" accept=".csv" onChange={handleFile} className="hidden" />
        </div>
      </GlassCard>

      {rows.length > 0 && (
        <>
          <GlassCard delay={0.1} className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading font-semibold flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-primary" /> Parsed Data ({rows.length} rows)
              </h2>
              {!imported && (
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={handleImport} className="btn-primary text-sm flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4" /> Import All
                </motion.button>
              )}
              {imported && <span className="text-success text-sm font-medium">✓ Imported</span>}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="py-2 px-3 text-left">Location</th>
                    <th className="py-2 px-3 text-left">Fever Cases</th>
                    <th className="py-2 px-3 text-left">Rainfall</th>
                    <th className="py-2 px-3 text-left">Water Quality</th>
                    <th className="py-2 px-3 text-left">Density</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-2 px-3">{row.location}</td>
                      <td className="py-2 px-3">{row.feverCases}</td>
                      <td className="py-2 px-3">{row.rainfall}</td>
                      <td className="py-2 px-3">{row.waterQuality}</td>
                      <td className="py-2 px-3">{row.populationDensity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>

          {chartData && (
            <GlassCard delay={0.2}>
              <h2 className="font-heading font-semibold mb-4">Uploaded Data Overview</h2>
              <div className="h-64"><Bar data={chartData} options={{ responsive: true, maintainAspectRatio: false }} /></div>
            </GlassCard>
          )}
        </>
      )}
    </div>
  );
};

export default CsvUpload;
