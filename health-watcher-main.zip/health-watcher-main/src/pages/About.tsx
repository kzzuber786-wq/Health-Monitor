import GlassCard from "@/components/GlassCard";
import { motion } from "framer-motion";
import { Activity, Brain, Smartphone, Wifi, Database, Shield, Globe, Zap } from "lucide-react";

const features = [
  { icon: Activity, title: "Real-time Monitoring", desc: "Track disease outbreaks as they happen with live data feeds" },
  { icon: Brain, title: "Risk Analysis Engine", desc: "Multi-factor analysis combining fever, rainfall, water quality & density" },
  { icon: Shield, title: "Alert System", desc: "Instant notifications when high-risk conditions are detected" },
  { icon: Database, title: "Data Management", desc: "CSV upload, manual entry, and persistent storage of health records" },
];

const futureScope = [
  { icon: Brain, title: "AI/ML Integration", desc: "Deep learning models for predictive outbreak forecasting" },
  { icon: Wifi, title: "Real-time Data", desc: "Integration with IoT sensors and government health APIs" },
  { icon: Smartphone, title: "Mobile App", desc: "Native mobile application for field health workers" },
  { icon: Globe, title: "Global Scale", desc: "Expand monitoring to cover international disease surveillance" },
  { icon: Zap, title: "Edge Computing", desc: "Process data locally for faster response in remote areas" },
];

const About = () => (
  <div className="container mx-auto px-4 py-8">
    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8 text-center">
      <div className="w-20 h-20 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
        <Activity className="w-10 h-10 text-primary-foreground" />
      </div>
      <h1 className="font-heading text-3xl font-bold">Smart Health Alert System</h1>
      <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
        An advanced prototype for early disease outbreak detection and risk assessment,
        designed for rapid deployment in public health emergencies.
      </p>
    </motion.div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
      {features.map((f, i) => (
        <GlassCard key={f.title} delay={i * 0.1}>
          <div className="flex gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <f.icon className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-heading font-semibold">{f.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
            </div>
          </div>
        </GlassCard>
      ))}
    </div>

    <motion.h2 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-heading text-2xl font-bold mb-6 text-center">
      Future Scope
    </motion.h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {futureScope.map((f, i) => (
        <GlassCard key={f.title} delay={0.4 + i * 0.1}>
          <f.icon className="w-8 h-8 text-secondary mb-3" />
          <h3 className="font-heading font-semibold">{f.title}</h3>
          <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
        </GlassCard>
      ))}
    </div>
  </div>
);

export default About;
