import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import { motion } from "framer-motion";
import { MapPin } from "lucide-react";

// Simulated city coordinates (relative % on India map)
const cityCoords: Record<string, { x: number; y: number }> = {
  Mumbai: { x: 30, y: 60 },
  Delhi: { x: 40, y: 25 },
  Bangalore: { x: 38, y: 78 },
  Chennai: { x: 50, y: 78 },
  Kolkata: { x: 65, y: 45 },
  Hyderabad: { x: 42, y: 65 },
  Pune: { x: 32, y: 62 },
  Jaipur: { x: 35, y: 32 },
};

const riskColor = (level: string) =>
  level === "High" ? "text-destructive" : level === "Medium" ? "text-warning" : "text-success";

const MapView = () => {
  const { records } = useHealthData();

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="font-heading text-3xl font-bold">Risk Map</h1>
        <p className="text-muted-foreground mt-1">Geographic visualization of health risk levels</p>
      </motion.div>

      <GlassCard className="relative">
        {/* Simplified map area */}
        <div className="relative w-full aspect-[3/4] max-w-lg mx-auto bg-muted/30 rounded-xl border border-border overflow-hidden">
          {/* India outline (simplified SVG) */}
          <svg viewBox="0 0 100 120" className="w-full h-full opacity-10" fill="none" stroke="currentColor" strokeWidth="0.5">
            <path d="M35,5 L50,8 L65,5 L72,15 L70,30 L75,45 L65,50 L68,65 L60,80 L55,95 L50,110 L45,100 L40,85 L35,75 L25,65 L20,50 L25,35 L30,20 Z" />
          </svg>

          {/* Risk markers */}
          {records.map((r) => {
            const coords = cityCoords[r.location] || { x: 50 + Math.random() * 20 - 10, y: 50 + Math.random() * 20 - 10 };
            return (
              <motion.div
                key={r.id}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="absolute flex flex-col items-center"
                style={{ left: `${coords.x}%`, top: `${coords.y}%`, transform: "translate(-50%, -50%)" }}
              >
                <div className={`relative ${r.riskLevel === "High" ? "animate-pulse-glow" : ""}`}>
                  <MapPin className={`w-8 h-8 ${riskColor(r.riskLevel)} drop-shadow-lg`} fill="currentColor" />
                </div>
                <span className="text-[10px] font-bold mt-0.5 bg-card/80 px-1.5 py-0.5 rounded text-foreground whitespace-nowrap">
                  {r.location}
                </span>
              </motion.div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 mt-6">
          {[
            { label: "High Risk", class: "text-destructive" },
            { label: "Medium Risk", class: "text-warning" },
            { label: "Low Risk", class: "text-success" },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-1.5 text-sm">
              <MapPin className={`w-4 h-4 ${item.class}`} fill="currentColor" />
              <span className="text-muted-foreground">{item.label}</span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};

export default MapView;
