import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useHealthData } from "@/context/HealthDataContext";
import GlassCard from "@/components/GlassCard";
import FloatingOrbs from "@/components/FloatingOrbs";
import { motion } from "framer-motion";
import { Send, MapPin, Thermometer, CloudRain, Droplets, Users, Sparkles } from "lucide-react";

const DataInput = () => {
  const { addRecord } = useHealthData();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    location: "", feverCases: "",
    rainfall: "Low" as "Low" | "Medium" | "High",
    waterQuality: "Good" as "Good" | "Poor",
    populationDensity: "Low" as "Low" | "Medium" | "High",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.location || !form.feverCases) return;
    addRecord({ ...form, feverCases: parseInt(form.feverCases) });
    setSubmitted(true);
    setTimeout(() => navigate("/results"), 1500);
  };

  const inputClass = "w-full px-4 py-3.5 rounded-xl bg-muted/50 border border-border hover:border-primary/30 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/40 transition-all duration-300 text-sm";

  const fields = [
    { key: "location", label: "Location", icon: MapPin, iconColor: "text-primary", type: "text", placeholder: "e.g. Mumbai" },
    { key: "feverCases", label: "Fever Cases", icon: Thermometer, iconColor: "text-destructive", type: "number", placeholder: "Number of reported cases" },
  ];

  return (
    <div className="relative min-h-screen">
      <FloatingOrbs />
      <div className="relative z-10 container mx-auto px-4 py-8 max-w-2xl">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Data Collection</span>
          </div>
          <h1 className="font-heading text-3xl lg:text-4xl font-extrabold tracking-tight">Submit Health Data</h1>
          <p className="text-muted-foreground mt-2">Enter surveillance data for AI-powered risk analysis</p>
        </motion.div>

        {submitted ? (
          <GlassCard className="text-center py-16">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200 }}>
              <div className="w-24 h-24 rounded-3xl gradient-primary flex items-center justify-center mx-auto mb-5" style={{ boxShadow: '0 0 60px hsl(199,89%,48%,0.3)' }}>
                <Send className="w-12 h-12 text-primary-foreground" />
              </div>
              <h2 className="font-heading text-2xl font-bold">Analysis Complete!</h2>
              <p className="text-muted-foreground mt-2">Redirecting to results...</p>
              <div className="mt-6 flex justify-center">
                <div className="h-1 w-48 rounded-full bg-muted overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 1.5 }} className="h-full gradient-primary rounded-full" />
                </div>
              </div>
            </motion.div>
          </GlassCard>
        ) : (
          <GlassCard>
            <form onSubmit={handleSubmit} className="space-y-5">
              {fields.map((f, i) => (
                <motion.div key={f.key} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}>
                  <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                    <f.icon className={`w-4 h-4 ${f.iconColor}`} /> {f.label}
                  </label>
                  <input type={f.type} value={(form as any)[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                    className={inputClass} placeholder={f.placeholder} required min={f.type === "number" ? "0" : undefined} />
                </motion.div>
              ))}
              {[
                { key: "rainfall", label: "Rainfall Level", icon: CloudRain, iconColor: "text-info", options: ["Low", "Medium", "High"] },
                { key: "waterQuality", label: "Water Quality", icon: Droplets, iconColor: "text-secondary", options: ["Good", "Poor"] },
                { key: "populationDensity", label: "Population Density", icon: Users, iconColor: "text-warning", options: ["Low", "Medium", "High"] },
              ].map((f, i) => (
                <motion.div key={f.key} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.1 }}>
                  <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                    <f.icon className={`w-4 h-4 ${f.iconColor}`} /> {f.label}
                  </label>
                  <div className="flex gap-2">
                    {f.options.map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => setForm({ ...form, [f.key]: opt })}
                        className={`flex-1 py-3 rounded-xl text-sm font-medium border transition-all duration-300 ${
                          (form as any)[f.key] === opt
                            ? "bg-primary/10 border-primary/40 text-primary"
                            : "bg-muted/30 border-border hover:border-primary/20 text-muted-foreground"
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </motion.div>
              ))}
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full btn-primary py-4 text-sm flex items-center justify-center gap-2 mt-4"
              >
                <Sparkles className="w-4 h-4" /> Analyze Risk
              </motion.button>
            </form>
          </GlassCard>
        )}
      </div>
    </div>
  );
};

export default DataInput;
