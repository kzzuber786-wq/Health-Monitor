import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import AnimatedCounter from "./AnimatedCounter";

interface StatCardProps {
  label: string;
  value: number;
  icon: LucideIcon;
  trend?: string;
  color: string;
  gradient: string;
  delay?: number;
}

const StatCard = ({ label, value, icon: Icon, trend, color, gradient, delay = 0 }: StatCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 30, scale: 0.95 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    className="stat-card group cursor-default"
  >
    <div className="flex items-start justify-between mb-4">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3 ${gradient}`}>
        <Icon className="w-5 h-5 text-primary-foreground" />
      </div>
      {trend && (
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${color}`}>
          {trend}
        </span>
      )}
    </div>
    <div className="text-3xl font-bold font-heading tracking-tight">
      <AnimatedCounter end={value} />
    </div>
    <p className="text-sm text-muted-foreground mt-1">{label}</p>
    {/* Decorative line */}
    <div className="mt-4 h-1 rounded-full bg-muted overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: "100%" }}
        transition={{ duration: 1.5, delay: delay + 0.3, ease: "easeOut" }}
        className={`h-full rounded-full ${gradient}`}
      />
    </div>
  </motion.div>
);

export default StatCard;
