import { motion } from "framer-motion";

const FloatingOrbs = () => (
  <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
    <motion.div
      className="floating-orb w-96 h-96 bg-primary/20 top-[-10%] left-[-5%]"
      animate={{ x: [0, 40, -20, 0], y: [0, -30, 20, 0] }}
      transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className="floating-orb w-72 h-72 bg-secondary/20 bottom-[10%] right-[-5%]"
      animate={{ x: [0, -30, 20, 0], y: [0, 20, -40, 0] }}
      transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
    />
    <motion.div
      className="floating-orb w-48 h-48 bg-purple-400/15 top-[40%] left-[50%]"
      animate={{ x: [0, 50, -30, 0], y: [0, -50, 30, 0] }}
      transition={{ duration: 14, repeat: Infinity, ease: "easeInOut", delay: 4 }}
    />
    {/* Grid pattern */}
    <div className="absolute inset-0" style={{
      backgroundImage: `
        linear-gradient(hsl(199, 89%, 48%, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, hsl(199, 89%, 48%, 0.03) 1px, transparent 1px)
      `,
      backgroundSize: '60px 60px',
      animation: 'gridPulse 4s ease-in-out infinite',
    }} />
  </div>
);

export default FloatingOrbs;
