import { motion } from "framer-motion";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  delay?: number;
  variant?: "default" | "dark" | "glow";
}

const GlassCard = ({ children, className = "", hover = true, delay = 0, variant = "default" }: GlassCardProps) => {
  const base = variant === "dark" ? "glass-dark" : variant === "glow" ? "glass-card border-primary/20" : (hover ? "glass-card-hover" : "glass-card");

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={`${base} p-6 ${className}`}
    >
      {children}
    </motion.div>
  );
};

export default GlassCard;
