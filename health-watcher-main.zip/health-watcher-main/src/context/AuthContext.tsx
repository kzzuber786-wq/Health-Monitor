import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface User {
  userId: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  login: (userId: string, password: string) => { success: boolean; message: string };
  signup: (userId: string, email: string, password: string) => { success: boolean; message: string };
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Simple hash function for demo purposes (simulates bcrypt)
const hashPassword = (password: string): string => {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return `hashed_${Math.abs(hash).toString(36)}`;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("health_alert_user");
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const signup = (userId: string, email: string, password: string) => {
    const users = JSON.parse(localStorage.getItem("health_alert_users") || "[]");
    if (users.find((u: any) => u.userId === userId)) {
      return { success: false, message: "User ID already exists" };
    }
    if (users.find((u: any) => u.email === email)) {
      return { success: false, message: "Email already registered" };
    }
    const hashedPw = hashPassword(password);
    users.push({ userId, email, password: hashedPw });
    localStorage.setItem("health_alert_users", JSON.stringify(users));
    return { success: true, message: "Account created successfully!" };
  };

  const login = (userId: string, password: string) => {
    const users = JSON.parse(localStorage.getItem("health_alert_users") || "[]");
    const hashedPw = hashPassword(password);
    const found = users.find((u: any) => u.userId === userId && u.password === hashedPw);
    if (found) {
      const userData = { userId: found.userId, email: found.email };
      setUser(userData);
      localStorage.setItem("health_alert_user", JSON.stringify(userData));
      return { success: true, message: "Login successful!" };
    }
    return { success: false, message: "Invalid credentials" };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("health_alert_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
