import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface HealthRecord {
  id: string;
  location: string;
  feverCases: number;
  rainfall: "Low" | "Medium" | "High";
  waterQuality: "Good" | "Poor";
  populationDensity: "Low" | "Medium" | "High";
  riskLevel: "Low" | "Medium" | "High";
  disease: string;
  timestamp: string;
}

interface HealthDataContextType {
  records: HealthRecord[];
  addRecord: (record: Omit<HealthRecord, "id" | "riskLevel" | "disease" | "timestamp">) => HealthRecord;
  alerts: string[];
  dismissAlert: (index: number) => void;
}

// Risk analysis logic
const analyzeRisk = (
  feverCases: number,
  rainfall: string,
  waterQuality: string,
  populationDensity: string
): { riskLevel: "Low" | "Medium" | "High"; disease: string } => {
  if (feverCases > 50 && rainfall === "High" && waterQuality === "Poor") {
    return { riskLevel: "High", disease: "Dengue" };
  }
  if ((feverCases >= 20 && feverCases <= 50) || populationDensity === "High") {
    return { riskLevel: "Medium", disease: "Viral Fever" };
  }
  return { riskLevel: "Low", disease: "Safe" };
};

const HealthDataContext = createContext<HealthDataContextType | null>(null);

export const HealthDataProvider = ({ children }: { children: ReactNode }) => {
  const [records, setRecords] = useState<HealthRecord[]>([]);
  const [alerts, setAlerts] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("health_records");
    if (stored) {
      setRecords(JSON.parse(stored));
    } else {
      // Seed demo data
      const seed: HealthRecord[] = [
        { id: "1", location: "Mumbai", feverCases: 65, rainfall: "High", waterQuality: "Poor", populationDensity: "High", riskLevel: "High", disease: "Dengue", timestamp: "2026-04-10" },
        { id: "2", location: "Delhi", feverCases: 35, rainfall: "Medium", waterQuality: "Good", populationDensity: "High", riskLevel: "Medium", disease: "Viral Fever", timestamp: "2026-04-11" },
        { id: "3", location: "Bangalore", feverCases: 12, rainfall: "Low", waterQuality: "Good", populationDensity: "Medium", riskLevel: "Low", disease: "Safe", timestamp: "2026-04-12" },
        { id: "4", location: "Chennai", feverCases: 55, rainfall: "High", waterQuality: "Poor", populationDensity: "High", riskLevel: "High", disease: "Dengue", timestamp: "2026-04-13" },
        { id: "5", location: "Kolkata", feverCases: 28, rainfall: "Medium", waterQuality: "Poor", populationDensity: "Medium", riskLevel: "Medium", disease: "Viral Fever", timestamp: "2026-04-14" },
      ];
      setRecords(seed);
      localStorage.setItem("health_records", JSON.stringify(seed));
      setAlerts(["⚠️ High risk detected in Mumbai – Dengue outbreak likely!", "⚠️ High risk detected in Chennai – Dengue outbreak likely!"]);
    }
  }, []);

  const addRecord = (input: Omit<HealthRecord, "id" | "riskLevel" | "disease" | "timestamp">) => {
    const { riskLevel, disease } = analyzeRisk(input.feverCases, input.rainfall, input.waterQuality, input.populationDensity);
    const record: HealthRecord = {
      ...input,
      id: Date.now().toString(),
      riskLevel,
      disease,
      timestamp: new Date().toISOString().split("T")[0],
    };
    const updated = [...records, record];
    setRecords(updated);
    localStorage.setItem("health_records", JSON.stringify(updated));
    if (riskLevel === "High") {
      setAlerts((prev) => [...prev, `⚠️ High risk detected in ${input.location} – ${disease} outbreak likely!`]);
    }
    return record;
  };

  const dismissAlert = (index: number) => {
    setAlerts((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <HealthDataContext.Provider value={{ records, addRecord, alerts, dismissAlert }}>
      {children}
    </HealthDataContext.Provider>
  );
};

export const useHealthData = () => {
  const ctx = useContext(HealthDataContext);
  if (!ctx) throw new Error("useHealthData must be used within HealthDataProvider");
  return ctx;
};
